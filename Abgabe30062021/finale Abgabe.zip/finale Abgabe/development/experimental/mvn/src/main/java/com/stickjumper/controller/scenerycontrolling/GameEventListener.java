package com.stickjumper.controller.scenerycontrolling;

import com.stickjumper.data.GameElement;

public interface GameEventListener {

    void onContact(GameElement gameElement);

}
