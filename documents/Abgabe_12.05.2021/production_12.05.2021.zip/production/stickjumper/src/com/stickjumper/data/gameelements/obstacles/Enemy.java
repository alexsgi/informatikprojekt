package com.stickjumper.data.gameelements.obstacles;

import com.stickjumper.data.gameelements.Obstacle;

import java.awt.*;

public class Enemy extends Obstacle {

    public Enemy(Point p, int speed) {
        super(p, speed);
    }
}
