package com.stickjumper.data.gameelements.obstacles;

import com.stickjumper.data.gameelements.Obstacle;

import java.awt.*;

public class SteadyObstacle extends Obstacle {

    public SteadyObstacle(Point p) {
        super(p);
    }
}
